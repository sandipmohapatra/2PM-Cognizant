<!DOCTYPE html>
<title>Employee Registration Success< </title>
<h1><center>Employee Registration Success</center></h1><hr>

</html>