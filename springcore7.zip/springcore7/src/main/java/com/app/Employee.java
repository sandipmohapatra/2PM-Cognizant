package com.app;

import org.springframework.beans.factory.annotation.Autowired;

public abstract class Employee 
{ 
	private int empId; 
	private String empName; 
	private double empSal; 
	@Autowired 
	private Address addr; 
	Employee() { 
		super(); 
	} 
	public int getEmpId() { 
		return empId; 
	} 
	public void setEmpId(int empId)
	{ 
		this.empId = empId; 
	} 
	public String getEmpName() { 
		return empName; 
	} 
	public void setEmpName(String empName) { 
		this.empName = empName; 
	} 
	public double getEmpSal() { 
		return empSal; 
	} 
	public void setEmpSal(double empSal) { 
		this.empSal = empSal; 
	} 

	public Address getAddr() { 
		return getAddress(); 
	} 

	public abstract Address getAddress(); 
	@Override 
	public String toString() { 
		return"Employee [empId=" + empId + ",empName=" + empName + ", empSal=" + empSal + ", addr=" +
				addr + "]"; 
	}   
} 
