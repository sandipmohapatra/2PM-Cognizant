import org.springframework.beans.factory.*;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.*;
public class Test {
	public static void main(String[] args) 
	{
	Resource res=new ClassPathResource("applicationContext.xml");//Takes the path of the xml file.
	BeanFactory fact=new XmlBeanFactory(res);
	
	Employee stud=(Employee)fact.getBean("obj1");
	System.out.println(stud);
	
	Employee stud1=(Employee)fact.getBean("obj2");
	System.out.println(stud1);
	}
}
